﻿namespace Handler.MediatorHandler.MediatorQuery.Orders
{
    public class GetAllOrdersQuery : IRequest<IEnumerable<Order>>
    {
    }
}
