﻿namespace Handler.MediatorHandler.MediatorQuery.Products
{
    public class GetAllProductsQuery : IRequest<IEnumerable<Product>>
    {
    }
}
