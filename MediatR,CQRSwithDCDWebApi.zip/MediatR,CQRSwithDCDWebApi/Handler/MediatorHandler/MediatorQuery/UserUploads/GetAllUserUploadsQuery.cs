﻿namespace Handler.MediatorHandler.MediatorQuery.UserUploads
{
    public class GetAllUserUploadsQuery : IRequest<IEnumerable<UserUpload>>
    {
    }
}
