﻿namespace Domin.Models
{
    public class CartProduct
    {
        public int CartId { get; set; }
        //public IList<Cart> Carts { get; set; } = new List<Cart>();
        public int ProductId { get; set; }
        //public IList<Product> Products { get; set; } = new List<Product>();
    }
}
