﻿namespace Domin.Routing.BaseRouter
{
    public partial class Router
    {
        private const string root = "Api";
        private const string version = "V1";
        private const string Rule = root + "/";
    }
}
