﻿namespace Domin.Sign_Up
{
    public class AddRole
    {
        public string UserId { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }
}
